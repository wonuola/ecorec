-- ============================================
-- RECYCLING FACTORY DATABASE SCHEMA
-- Run this in Supabase SQL Editor
-- ============================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users & Authentication
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin', 'owner', 'procurement', 'warehouse_officer', 'sorting_supervisor', 'production_supervisor', 'logistics_officer', 'finance', 'auditor')),
  phone TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW(),
  last_login TIMESTAMP
);

-- Vendors
CREATE TABLE vendors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  contact_person TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  location TEXT NOT NULL,
  material_types TEXT[] DEFAULT '{}',
  reliability_score INTEGER DEFAULT 70 CHECK (reliability_score BETWEEN 0 AND 100),
  notes TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW(),
  total_transactions INTEGER DEFAULT 0,
  total_kg_purchased INTEGER DEFAULT 0
);

-- Buyers
CREATE TABLE buyers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  contact_person TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  location TEXT NOT NULL,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW(),
  total_transactions INTEGER DEFAULT 0,
  total_kg_sold INTEGER DEFAULT 0
);

-- Purchase Lots
CREATE TABLE purchase_lots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lot_number TEXT UNIQUE NOT NULL,
  vendor_id UUID REFERENCES vendors(id),
  material_type TEXT NOT NULL,
  grade TEXT NOT NULL CHECK (grade IN ('A', 'B', 'C')),
  gross_weight NUMERIC NOT NULL,
  tare_weight NUMERIC DEFAULT 0,
  net_weight NUMERIC NOT NULL,
  base_price_per_kg NUMERIC NOT NULL,
  grade_adjustment NUMERIC DEFAULT 0,
  moisture_adjustment NUMERIC DEFAULT 0,
  contamination_adjustment NUMERIC DEFAULT 0,
  final_price_per_kg NUMERIC NOT NULL,
  total_cost NUMERIC NOT NULL,
  payment_status TEXT DEFAULT 'pending' CHECK (payment_status IN ('pending', 'partial', 'paid')),
  amount_paid NUMERIC DEFAULT 0,
  trip_id UUID,
  receipt_photo TEXT,
  notes TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW(),
  handling_costs NUMERIC DEFAULT 0,
  logistics_costs NUMERIC DEFAULT 0,
  landed_cost_per_kg NUMERIC
);

-- Batches
CREATE TABLE batches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  batch_number TEXT UNIQUE NOT NULL,
  source_lot_ids UUID[] DEFAULT '{}',
  current_state TEXT DEFAULT 'unsorted_pet',
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'completed', 'dispatched')),
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW(),
  completed_at TIMESTAMP,
  
  -- Weights
  initial_weight NUMERIC DEFAULT 0,
  sorted_pet_weight NUMERIC DEFAULT 0,
  caps_weight NUMERIC DEFAULT 0,
  labels_weight NUMERIC DEFAULT 0,
  sorting_rejects_weight NUMERIC DEFAULT 0,
  ground_flakes_weight NUMERIC DEFAULT 0,
  washed_flakes_weight NUMERIC DEFAULT 0,
  dewatered_flakes_weight NUMERIC DEFAULT 0,
  final_dry_flakes_weight NUMERIC DEFAULT 0,
  
  -- Yields
  sorting_yield_percent NUMERIC DEFAULT 0,
  grinding_yield_percent NUMERIC DEFAULT 0,
  washing_loss_percent NUMERIC DEFAULT 0,
  total_yield_percent NUMERIC DEFAULT 0,
  
  -- Costs
  material_cost NUMERIC DEFAULT 0,
  sorting_cost NUMERIC DEFAULT 0,
  grinding_cost NUMERIC DEFAULT 0,
  washing_cost NUMERIC DEFAULT 0,
  handling_cost NUMERIC DEFAULT 0,
  logistics_cost NUMERIC DEFAULT 0,
  diesel_allocation NUMERIC DEFAULT 0,
  power_allocation NUMERIC DEFAULT 0,
  maintenance_cost NUMERIC DEFAULT 0,
  chemicals_cost NUMERIC DEFAULT 0,
  total_cost NUMERIC DEFAULT 0,
  cost_per_kg NUMERIC DEFAULT 0
);

-- Trips
CREATE TABLE trips (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  trip_number TEXT UNIQUE NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('inbound', 'outbound')),
  status TEXT DEFAULT 'planned' CHECK (status IN ('planned', 'in_transit', 'arrived', 'completed')),
  vehicle_number TEXT NOT NULL,
  vehicle_type TEXT,
  driver_name TEXT NOT NULL,
  driver_phone TEXT,
  origin TEXT NOT NULL,
  destination TEXT NOT NULL,
  fuel_cost NUMERIC DEFAULT 0,
  driver_wage NUMERIC DEFAULT 0,
  other_costs NUMERIC DEFAULT 0,
  total_cost NUMERIC DEFAULT 0,
  linked_lot_ids UUID[] DEFAULT '{}',
  linked_dispatch_id UUID,
  departure_time TIMESTAMP,
  arrival_time TIMESTAMP,
  notes TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW()
);

-- Handling Types
CREATE TABLE handling_types (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  direction TEXT NOT NULL CHECK (direction IN ('inbound', 'internal', 'outbound')),
  default_unit TEXT DEFAULT 'kg',
  is_active BOOLEAN DEFAULT true
);

-- Handling Events
CREATE TABLE handling_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  handling_type_id UUID REFERENCES handling_types(id),
  direction TEXT NOT NULL,
  linked_type TEXT NOT NULL,
  linked_id UUID NOT NULL,
  quantity NUMERIC NOT NULL,
  unit TEXT NOT NULL,
  rate NUMERIC NOT NULL,
  amount NUMERIC NOT NULL,
  paid_to TEXT NOT NULL,
  payment_method TEXT DEFAULT 'cash',
  is_paid BOOLEAN DEFAULT false,
  approved_by UUID REFERENCES users(id),
  approved_at TIMESTAMP,
  timestamp TIMESTAMP DEFAULT NOW(),
  notes TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW()
);

-- Workers
CREATE TABLE workers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  role TEXT DEFAULT 'general' CHECK (role IN ('sorter', 'loader', 'operator', 'general')),
  base_wage_rate NUMERIC DEFAULT 50,
  is_active BOOLEAN DEFAULT true,
  joined_at TIMESTAMP DEFAULT NOW(),
  total_kg_sorted NUMERIC DEFAULT 0,
  total_wages_earned NUMERIC DEFAULT 0
);

-- Sorting Operations
CREATE TABLE sorting_operations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  batch_id UUID REFERENCES batches(id),
  input_weight NUMERIC NOT NULL,
  sorted_pet_weight NUMERIC NOT NULL,
  caps_weight NUMERIC DEFAULT 0,
  labels_weight NUMERIC DEFAULT 0,
  rejects_weight NUMERIC DEFAULT 0,
  yield_percent NUMERIC,
  reject_percent NUMERIC,
  byproduct_percent NUMERIC,
  team_leader TEXT,
  worker_ids UUID[] DEFAULT '{}',
  start_time TIMESTAMP NOT NULL,
  end_time TIMESTAMP NOT NULL,
  duration_minutes INTEGER,
  notes TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW()
);

-- Wage Entries
CREATE TABLE wage_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  worker_id UUID REFERENCES workers(id),
  operation_type TEXT NOT NULL,
  operation_id UUID NOT NULL,
  quantity NUMERIC NOT NULL,
  rate NUMERIC NOT NULL,
  amount NUMERIC NOT NULL,
  is_team_split BOOLEAN DEFAULT false,
  team_size INTEGER,
  is_paid BOOLEAN DEFAULT false,
  paid_at TIMESTAMP,
  paid_by UUID REFERENCES users(id),
  approved_by UUID REFERENCES users(id),
  approved_at TIMESTAMP,
  period_start DATE,
  period_end DATE,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW()
);

-- Expenses
CREATE TABLE expenses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  category TEXT NOT NULL,
  amount NUMERIC NOT NULL,
  description TEXT NOT NULL,
  receipt_photo TEXT,
  allocated_to TEXT,
  batch_id UUID REFERENCES batches(id),
  department TEXT,
  shift_date DATE,
  is_paid BOOLEAN DEFAULT false,
  paid_at TIMESTAMP,
  approved_by UUID REFERENCES users(id),
  approved_at TIMESTAMP,
  expense_date DATE DEFAULT CURRENT_DATE,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW()
);

-- Dispatches
CREATE TABLE dispatches (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dispatch_number TEXT UNIQUE NOT NULL,
  buyer_id UUID REFERENCES buyers(id),
  batch_ids UUID[] DEFAULT '{}',
  total_weight NUMERIC NOT NULL,
  price_per_kg NUMERIC NOT NULL,
  total_value NUMERIC NOT NULL,
  handling_cost NUMERIC DEFAULT 0,
  delivery_cost NUMERIC DEFAULT 0,
  total_cost NUMERIC NOT NULL,
  factory_weight NUMERIC NOT NULL,
  buyer_confirmed_weight NUMERIC DEFAULT 0,
  variance_kg NUMERIC DEFAULT 0,
  variance_percent NUMERIC DEFAULT 0,
  status TEXT DEFAULT 'preparing' CHECK (status IN ('preparing', 'in_transit', 'delivered', 'confirmed', 'invoiced', 'paid')),
  payment_status TEXT DEFAULT 'pending' CHECK (payment_status IN ('pending', 'partial', 'paid')),
  amount_paid NUMERIC DEFAULT 0,
  profit NUMERIC DEFAULT 0,
  profit_margin NUMERIC DEFAULT 0,
  trip_id UUID REFERENCES trips(id),
  invoice_number TEXT,
  invoiced_at TIMESTAMP,
  dispatched_at TIMESTAMP DEFAULT NOW(),
  delivered_at TIMESTAMP,
  confirmed_at TIMESTAMP,
  notes TEXT,
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMP DEFAULT NOW()
);

-- Audit Logs
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id UUID NOT NULL,
  field_name TEXT,
  old_value TEXT,
  new_value TEXT,
  performed_by UUID REFERENCES users(id),
  performed_at TIMESTAMP DEFAULT NOW(),
  ip_address TEXT,
  user_agent TEXT,
  reason TEXT
);

-- Alerts
CREATE TABLE alerts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  type TEXT NOT NULL,
  severity TEXT DEFAULT 'medium' CHECK (severity IN ('low', 'medium', 'high', 'critical')),
  message TEXT NOT NULL,
  entity_type TEXT,
  entity_id UUID,
  is_read BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================
-- INSERT DEFAULT DATA
-- ============================================

-- Default handling types
INSERT INTO handling_types (name, direction, default_unit) VALUES
('Offloading', 'inbound', 'kg'),
('Loading', 'outbound', 'kg'),
('Bagging', 'internal', 'bag'),
('Unbagging', 'internal', 'bag'),
('Forklift Rental', 'internal', 'hour'),
('Yard Movement', 'internal', 'kg'),
('Tipping Fee', 'inbound', 'kg'),
('Weighing Assistance', 'inbound', 'trip');

-- Default users (passwordless login for demo)
INSERT INTO users (email, name, role, is_active) VALUES
('admin@factory.com', 'System Admin', 'admin', true),
('owner@factory.com', 'Factory Owner', 'owner', true),
('procurement@factory.com', 'Procurement Officer', 'procurement', true),
('warehouse@factory.com', 'Warehouse Officer', 'warehouse_officer', true),
('sorting@factory.com', 'Sorting Supervisor', 'sorting_supervisor', true),
('production@factory.com', 'Production Supervisor', 'production_supervisor', true),
('logistics@factory.com', 'Logistics Officer', 'logistics_officer', true),
('finance@factory.com', 'Finance Manager', 'finance', true);

-- Sample vendors
INSERT INTO vendors (name, contact_person, phone, location, material_types, reliability_score, notes, is_active, total_transactions, total_kg_purchased) VALUES
('ABC Recycling Ltd', 'John Doe', '08012345678', 'Lagos', ARRAY['PET', 'HDPE'], 85, 'Reliable supplier', true, 45, 125000),
('EcoCollectors', 'Jane Smith', '08087654321', 'Ibadan', ARRAY['PET'], 78, 'Good quality, sometimes late', true, 32, 89000),
('GreenPlast Ventures', 'Mike Johnson', '08055551234', 'Abuja', ARRAY['PET', 'PP'], 92, 'Premium quality, higher prices', true, 28, 76000);

-- Sample buyers
INSERT INTO buyers (name, contact_person, phone, location, is_active, total_transactions, total_kg_sold) VALUES
('Nigerian Plastics Inc', 'Robert Chen', '07011112222', 'Lagos', true, 38, 98000),
('EuroPack Nigeria', 'Maria Garcia', '07033334444', 'Port Harcourt', true, 25, 65000),
('AfriFiber Industries', 'David Okonkwo', '07055556666', 'Onitsha', true, 20, 48000);

-- Sample workers
INSERT INTO workers (name, phone, role, base_wage_rate, is_active, total_kg_sorted, total_wages_earned) VALUES
('Emmanuel Adeyemi', '08111111111', 'sorter', 50, true, 15000, 750000),
('Fatima Bello', '08122222222', 'sorter', 50, true, 12000, 600000),
('Chinedu Okafor', '08133333333', 'loader', 2000, true, 0, 180000),
('Amina Ibrahim', '08144444444', 'operator', 5000, true, 0, 350000),
('Tunde Bakare', '08155555555', 'sorter', 50, true, 8000, 400000);

-- ============================================
-- ENABLE ROW LEVEL SECURITY (Optional but recommended)
-- ============================================

-- Enable RLS on all tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE vendors ENABLE ROW LEVEL SECURITY;
ALTER TABLE buyers ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchase_lots ENABLE ROW LEVEL SECURITY;
ALTER TABLE batches ENABLE ROW LEVEL SECURITY;
ALTER TABLE trips ENABLE ROW LEVEL SECURITY;
ALTER TABLE handling_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE workers ENABLE ROW LEVEL SECURITY;
ALTER TABLE sorting_operations ENABLE ROW LEVEL SECURITY;
ALTER TABLE wage_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE dispatches ENABLE ROW LEVEL SECURITY;

-- Create policies (allow all access for now - customize later)
CREATE POLICY "Allow all" ON users FOR ALL USING (true);
CREATE POLICY "Allow all" ON vendors FOR ALL USING (true);
CREATE POLICY "Allow all" ON buyers FOR ALL USING (true);
CREATE POLICY "Allow all" ON purchase_lots FOR ALL USING (true);
CREATE POLICY "Allow all" ON batches FOR ALL USING (true);
CREATE POLICY "Allow all" ON trips FOR ALL USING (true);
CREATE POLICY "Allow all" ON handling_events FOR ALL USING (true);
CREATE POLICY "Allow all" ON workers FOR ALL USING (true);
CREATE POLICY "Allow all" ON sorting_operations FOR ALL USING (true);
CREATE POLICY "Allow all" ON wage_entries FOR ALL USING (true);
CREATE POLICY "Allow all" ON expenses FOR ALL USING (true);
CREATE POLICY "Allow all" ON dispatches FOR ALL USING (true);
