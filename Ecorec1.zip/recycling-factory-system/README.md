# Recycling Factory Management System

A comprehensive web-based digital nervous system for wet plastic flakes recycling operations. Track every kilogram from procurement to dispatch.

## Features

- **Vendor & Procurement** - Vendor registration, reliability scoring, price engine
- **Logistics** - Trip planning, vehicle tracking, fuel costs
- **Handling** - Cost tracking for offloading, loading, bagging, forklift
- **Warehouse** - Inventory by state (unsorted → sorted → ground → washed → final)
- **Sorting** - Weight recording, yield % calculation, byproduct tracking
- **Wages** - Worker productivity tracking, wage calculation
- **Production** - Grinding & washing with multi-stage checkpoints
- **Expenses** - Quick-entry with batch/department/shift allocation
- **Sales & Dispatch** - Buyer management, weight variance tracking
- **Reports** - Production yields, financial breakdowns, workforce productivity

## Tech Stack

- React + TypeScript + Vite
- Tailwind CSS + shadcn/ui
- Supabase (PostgreSQL + Auth)
- Recharts for visualizations

## Quick Start

### 1. Create Supabase Project

1. Go to [supabase.com](https://supabase.com) and create an account
2. Click "New Project" → Name it `recycling-factory`
3. Wait for project creation (~2 minutes)
4. Go to **SQL Editor** → **New Query**
5. Copy the contents of `supabase-schema.sql` and run it
6. Go to **Settings** → **API** and copy:
   - Project URL
   - anon public API key

### 2. Set Up Environment Variables

1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```

2. Fill in your Supabase credentials:
   ```
   VITE_SUPABASE_URL=https://your-project.supabase.co
   VITE_SUPABASE_ANON_KEY=your-anon-key-here
   ```

### 3. Install Dependencies

```bash
npm install
```

### 4. Run Locally

```bash
npm run dev
```

Open http://localhost:5173 in your browser.

### 5. Deploy to Vercel

1. Push this code to GitHub
2. Go to [vercel.com](https://vercel.com) and sign up with GitHub
3. Click "Add New Project" → Import your repository
4. Add environment variables in Vercel settings:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
5. Click "Deploy"

### 6. Connect Your Domain (Optional)

1. Buy a domain from Namecheap or Cloudflare
2. In Vercel, go to Project Settings → Domains
3. Add your domain and follow DNS instructions

## Default Login Credentials

| Email | Role |
|-------|------|
| admin@factory.com | Full system access |
| owner@factory.com | Owner dashboard |
| procurement@factory.com | Purchase management |
| warehouse@factory.com | Inventory control |
| sorting@factory.com | Sorting operations |
| production@factory.com | Production tracking |
| logistics@factory.com | Trip management |
| finance@factory.com | Financial reports |

**Password:** Any password works (demo mode)

## Database Schema

The system uses 18 core tables:
- `users` - System users with roles
- `vendors` - Supplier information
- `buyers` - Customer information
- `purchase_lots` - Raw material purchases
- `batches` - Production units
- `trips` - Logistics tracking
- `handling_types` & `handling_events` - Cost tracking
- `workers` & `wage_entries` - Workforce management
- `sorting_operations` - Sorting yield data
- `expenses` - All expenses with allocation
- `dispatches` - Sales and deliveries
- `audit_logs` - Change tracking
- `alerts` - System notifications

## Folder Structure

```
├── src/
│   ├── components/ui/    # UI components (buttons, cards, etc.)
│   ├── sections/         # Main modules (Dashboard, Vendor, etc.)
│   ├── hooks/           # Authentication & custom hooks
│   ├── services/        # Database connection
│   ├── types/           # TypeScript type definitions
│   └── lib/             # Utility functions
├── public/              # Static assets
└── supabase-schema.sql  # Database setup script
```

## Customization

### Add Your Logo
Replace `public/vite.svg` with your company logo.

### Change Colors
Edit `tailwind.config.js` to match your brand colors.

### Add More Users
Insert into the `users` table in Supabase.

## Support

For issues or questions:
1. Check Supabase documentation: supabase.com/docs
2. Check Vercel documentation: vercel.com/docs
3. Open an issue on GitHub

## License

MIT License - Free for commercial use.
