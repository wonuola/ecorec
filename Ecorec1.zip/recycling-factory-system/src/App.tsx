// ============================================================================
// RECYCLING FACTORY MANAGEMENT SYSTEM - MAIN APP
// ============================================================================

import { useState } from 'react';
import { AuthProvider, useAuth } from '@/hooks/useAuth';
import { LoginPage } from '@/sections/LoginPage';
import { Dashboard } from '@/sections/Dashboard';
import { VendorModule } from '@/sections/VendorModule';
import { ProcurementModule } from '@/sections/ProcurementModule';
import { LogisticsModule } from '@/sections/LogisticsModule';
import { HandlingModule } from '@/sections/HandlingModule';
import { WarehouseModule } from '@/sections/WarehouseModule';
import { SortingModule } from '@/sections/SortingModule';
import { WagesModule } from '@/sections/WagesModule';
import { ProductionModule } from '@/sections/ProductionModule';
import { ExpensesModule } from '@/sections/ExpensesModule';
import { SalesModule } from '@/sections/SalesModule';
import { ReportsModule } from '@/sections/ReportsModule';
import { TicketsModule } from '@/sections/TicketsModule';
import { Button } from '@/components/ui/button';
import { 
  LayoutDashboard, 
  Users, 
  ShoppingCart, 
  Truck, 
  Hand, 
  Warehouse, 
  Filter, 
  Banknote, 
  Factory, 
  Receipt, 
  TrendingUp, 
  LogOut,
  Menu,
  Bell,
  User,
  Ticket
} from 'lucide-react';
import { cn } from '@/lib/utils';

type ModuleType = 
  | 'dashboard'
  | 'vendors'
  | 'procurement'
  | 'logistics'
  | 'handling'
  | 'warehouse'
  | 'sorting'
  | 'wages'
  | 'production'
  | 'expenses'
  | 'sales'
  | 'reports'
  | 'tickets';

interface NavItem {
  id: ModuleType;
  label: string;
  icon: React.ElementType;
  permissions: string[];
}

const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, permissions: ['view_dashboard'] },
  { id: 'vendors', label: 'Vendors & Buyers', icon: Users, permissions: ['view_vendors'] },
  { id: 'procurement', label: 'Procurement', icon: ShoppingCart, permissions: ['view_lots'] },
  { id: 'logistics', label: 'Logistics', icon: Truck, permissions: ['view_trips'] },
  { id: 'handling', label: 'Handling', icon: Hand, permissions: ['view_handling'] },
  { id: 'warehouse', label: 'Warehouse', icon: Warehouse, permissions: ['view_batches'] },
  { id: 'sorting', label: 'Sorting', icon: Filter, permissions: ['view_sorting'] },
  { id: 'wages', label: 'Wages', icon: Banknote, permissions: ['view_wages'] },
  { id: 'production', label: 'Production', icon: Factory, permissions: ['view_batches'] },
  { id: 'expenses', label: 'Expenses', icon: Receipt, permissions: ['view_expenses'] },
  { id: 'sales', label: 'Sales & Dispatch', icon: TrendingUp, permissions: ['view_dispatches'] },
  { id: 'tickets', label: 'Tickets', icon: Ticket, permissions: ['view_tickets'] },
  { id: 'reports', label: 'Reports', icon: TrendingUp, permissions: ['view_reports'] },
];

function AppContent() {
  const { user, isAuthenticated, logout, hasPermission } = useAuth();
  const [currentModule, setCurrentModule] = useState<ModuleType>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  const filteredNavItems = NAV_ITEMS.filter(item => 
    item.permissions.some(p => hasPermission(p as any))
  );

  const renderModule = () => {
    switch (currentModule) {
      case 'dashboard':
        return <Dashboard />;
      case 'vendors':
        return <VendorModule />;
      case 'procurement':
        return <ProcurementModule />;
      case 'logistics':
        return <LogisticsModule />;
      case 'handling':
        return <HandlingModule />;
      case 'warehouse':
        return <WarehouseModule />;
      case 'sorting':
        return <SortingModule />;
      case 'wages':
        return <WagesModule />;
      case 'production':
        return <ProductionModule />;
      case 'expenses':
        return <ExpensesModule />;
      case 'sales':
        return <SalesModule />;
      case 'tickets':
        return <TicketsModule />;
      case 'reports':
        return <ReportsModule />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside 
        className={cn(
          "fixed lg:static inset-y-0 left-0 z-50 w-64 bg-slate-900 text-white transition-transform duration-200 ease-in-out",
          sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        <div className="p-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
              <Factory className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-lg leading-tight">EcoRecycle</h1>
              <p className="text-xs text-slate-400">Factory Management</p>
            </div>
          </div>
        </div>

        <nav className="p-2 space-y-1 overflow-y-auto max-h-[calc(100vh-140px)]">
          {filteredNavItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setCurrentModule(item.id);
                  setSidebarOpen(false);
                }}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                  currentModule === item.id
                    ? "bg-green-600 text-white"
                    : "text-slate-300 hover:bg-slate-800 hover:text-white"
                )}
              >
                <Icon className="w-5 h-5" />
                {item.label}
              </button>
            );
          })}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-slate-800">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-8 h-8 bg-slate-700 rounded-full flex items-center justify-center">
              <User className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user?.name}</p>
              <p className="text-xs text-slate-400 capitalize">{user?.role.replace('_', ' ')}</p>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            className="w-full text-slate-300 hover:text-white hover:bg-slate-800"
            onClick={logout}
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 min-w-0">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 sticky top-0 z-30">
          <div className="flex items-center justify-between px-4 py-3">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="icon"
                className="lg:hidden"
                onClick={() => setSidebarOpen(true)}
              >
                <Menu className="w-5 h-5" />
              </Button>
              <h2 className="text-lg font-semibold text-gray-900">
                {NAV_ITEMS.find(i => i.id === currentModule)?.label}
              </h2>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="w-5 h-5" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
              </Button>
            </div>
          </div>
        </header>

        {/* Module Content */}
        <div className="p-4 lg:p-6">
          {renderModule()}
        </div>
      </main>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
