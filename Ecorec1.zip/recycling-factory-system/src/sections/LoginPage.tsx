// ============================================================================
// LOGIN PAGE
// ============================================================================

import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Factory, AlertCircle, Loader2 } from 'lucide-react';

export function LoginPage() {
  const { login, isLoading } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!email || !password) {
      setError('Please enter both email and password');
      return;
    }

    const success = await login({ email, password });
    if (!success) {
      setError('Invalid credentials. Try: admin@factory.com / any password');
    }
  };

  // Demo credentials helper
  const fillDemoCredentials = (role: string) => {
    const credentials: Record<string, string> = {
      admin: 'admin@factory.com',
      owner: 'owner@factory.com',
      procurement: 'procurement@factory.com',
      warehouse: 'warehouse@factory.com',
      sorting: 'sorting@factory.com',
      production: 'production@factory.com',
      logistics: 'logistics@factory.com',
      finance: 'finance@factory.com',
    };
    setEmail(credentials[role] || '');
    setPassword('password');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="flex justify-center mb-8">
          <div className="w-20 h-20 bg-green-500 rounded-2xl flex items-center justify-center shadow-lg shadow-green-500/20">
            <Factory className="w-12 h-12 text-white" />
          </div>
        </div>

        <Card className="border-0 shadow-2xl bg-white/95 backdrop-blur">
          <CardHeader className="text-center pb-2">
            <CardTitle className="text-2xl font-bold text-slate-900">
              EcoRecycle Factory
            </CardTitle>
            <CardDescription className="text-slate-500">
              Sign in to access the management system
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            {error && (
              <Alert variant="destructive" className="mb-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-11"
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-11"
                  disabled={isLoading}
                />
              </div>

              <Button 
                type="submit" 
                className="w-full h-11 bg-green-600 hover:bg-green-700"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Signing in...
                  </>
                ) : (
                  'Sign In'
                )}
              </Button>
            </form>

            {/* Demo Credentials */}
            <div className="mt-6 pt-4 border-t border-gray-100">
              <p className="text-xs text-gray-500 text-center mb-3">Quick login (any password works)</p>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { label: 'Admin', role: 'admin' },
                  { label: 'Owner', role: 'owner' },
                  { label: 'Procurement', role: 'procurement' },
                  { label: 'Warehouse', role: 'warehouse' },
                  { label: 'Sorting', role: 'sorting' },
                  { label: 'Production', role: 'production' },
                  { label: 'Logistics', role: 'logistics' },
                  { label: 'Finance', role: 'finance' },
                ].map(({ label, role }) => (
                  <button
                    key={role}
                    type="button"
                    onClick={() => fillDemoCredentials(role)}
                    className="text-xs px-2 py-1.5 bg-slate-100 hover:bg-slate-200 rounded text-slate-600 transition-colors"
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        <p className="text-center text-slate-400 text-sm mt-6">
          © 2024 EcoRecycle Factory Management System
        </p>
      </div>
    </div>
  );
}
