// ============================================================================
// TICKETS MODULE - Production Problem Solving
// ============================================================================

import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { db as databaseService } from '@/services/database';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Ticket, TicketStatus, TicketPriority, TicketCategory, Batch } from '@/types';
import { 
  Plus, 
  Search, 
  AlertCircle, 
  Clock, 
  CheckCircle, 
  XCircle, 
  MessageSquare,
  Filter,
  Wrench,
  ShieldAlert,
  Zap,
  Package,
  AlertTriangle,
  MoreHorizontal,
  Link as LinkIcon,
  User
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

const CATEGORY_ICONS: Record<TicketCategory, React.ElementType> = {
  equipment_failure: Wrench,
  quality_issue: AlertTriangle,
  safety_concern: ShieldAlert,
  process_delay: Clock,
  material_shortage: Package,
  power_outage: Zap,
  maintenance: Wrench,
  other: AlertCircle,
};

const CATEGORY_LABELS: Record<TicketCategory, string> = {
  equipment_failure: 'Equipment Failure',
  quality_issue: 'Quality Issue',
  safety_concern: 'Safety Concern',
  process_delay: 'Process Delay',
  material_shortage: 'Material Shortage',
  power_outage: 'Power Outage',
  maintenance: 'Maintenance',
  other: 'Other',
};

const PRIORITY_COLORS: Record<TicketPriority, string> = {
  low: 'bg-blue-100 text-blue-800 border-blue-200',
  medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  high: 'bg-orange-100 text-orange-800 border-orange-200',
  critical: 'bg-red-100 text-red-800 border-red-200',
};

const STATUS_COLORS: Record<TicketStatus, string> = {
  open: 'bg-red-100 text-red-800 border-red-200',
  in_progress: 'bg-yellow-100 text-yellow-800 border-yellow-200',
  resolved: 'bg-green-100 text-green-800 border-green-200',
  closed: 'bg-gray-100 text-gray-800 border-gray-200',
};

export function TicketsModule() {
  const { user, hasPermission } = useAuth();
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [batches, setBatches] = useState<Batch[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<TicketCategory | 'all'>('all');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);

  // Form state
  const [newTicket, setNewTicket] = useState({
    title: '',
    description: '',
    category: 'equipment_failure' as TicketCategory,
    priority: 'medium' as TicketPriority,
    linkedBatchId: '',
  });
  const [newComment, setNewComment] = useState('');
  const [resolution, setResolution] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    const [ticketsData, batchesData] = await Promise.all([
      databaseService.getTickets(),
      databaseService.getBatches(),
    ]);
    setTickets(ticketsData);
    setBatches(batchesData.filter(b => b.status === 'active'));
    setLoading(false);
  };

  const filteredTickets = tickets.filter(ticket => {
    const matchesSearch = 
      ticket.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.ticketNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || ticket.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const ticketsByStatus = {
    open: filteredTickets.filter(t => t.status === 'open'),
    in_progress: filteredTickets.filter(t => t.status === 'in_progress'),
    resolved: filteredTickets.filter(t => t.status === 'resolved'),
    closed: filteredTickets.filter(t => t.status === 'closed'),
  };

  const handleCreateTicket = async () => {
    if (!user || !newTicket.title.trim() || !newTicket.description.trim()) return;

    await databaseService.createTicket({
      ...newTicket,
      linkedBatchId: newTicket.linkedBatchId || undefined,
    }, user.id);

    setNewTicket({
      title: '',
      description: '',
      category: 'equipment_failure',
      priority: 'medium',
      linkedBatchId: '',
    });
    setIsCreateDialogOpen(false);
    loadData();
  };

  const handleAddComment = async () => {
    if (!user || !selectedTicket || !newComment.trim()) return;

    await databaseService.addTicketComment(selectedTicket.id, newComment, user.id);
    setNewComment('');
    loadData();
    
    // Refresh selected ticket
    const updated = await databaseService.getTicketById(selectedTicket.id);
    if (updated) setSelectedTicket(updated);
  };

  const handleUpdateStatus = async (status: TicketStatus) => {
    if (!user || !selectedTicket) return;

    await databaseService.updateTicketStatus(selectedTicket.id, status, user.id, resolution || undefined);
    
    if (status === 'resolved' || status === 'closed') {
      setResolution('');
    }
    
    loadData();
    const updated = await databaseService.getTicketById(selectedTicket.id);
    if (updated) setSelectedTicket(updated);
  };

  const canCreateTicket = hasPermission('create_ticket') || hasPermission('manage_tickets');
  const canManageTickets = hasPermission('manage_tickets');

  const renderTicketCard = (ticket: Ticket) => {
    const CategoryIcon = CATEGORY_ICONS[ticket.category];
    
    return (
      <Card 
        key={ticket.id} 
        className="cursor-pointer hover:shadow-md transition-shadow"
        onClick={() => {
          setSelectedTicket(ticket);
          setIsViewDialogOpen(true);
        }}
      >
        <CardContent className="p-4">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs text-gray-500">{ticket.ticketNumber}</span>
                <Badge variant="outline" className={cn('text-xs', PRIORITY_COLORS[ticket.priority])}>
                  {ticket.priority}
                </Badge>
              </div>
              <h4 className="font-medium text-sm truncate">{ticket.title}</h4>
              <p className="text-xs text-gray-500 mt-1 line-clamp-2">{ticket.description}</p>
            </div>
            <CategoryIcon className="w-5 h-5 text-gray-400 flex-shrink-0" />
          </div>
          
          <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className={cn('text-xs', STATUS_COLORS[ticket.status])}>
                {ticket.status.replace('_', ' ')}
              </Badge>
              {ticket.comments.length > 0 && (
                <span className="flex items-center gap-1 text-xs text-gray-500">
                  <MessageSquare className="w-3 h-3" />
                  {ticket.comments.length}
                </span>
              )}
            </div>
            <span className="text-xs text-gray-400">
              {format(new Date(ticket.createdAt), 'MMM d')}
            </span>
          </div>
          
          {ticket.linkedBatch && (
            <div className="flex items-center gap-1 mt-2 text-xs text-blue-600">
              <LinkIcon className="w-3 h-3" />
              Linked to {ticket.linkedBatch.batchNumber}
            </div>
          )}
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Production Tickets</h2>
          <p className="text-gray-500">Track and resolve production issues</p>
        </div>
        {canCreateTicket && (
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-green-600 hover:bg-green-700">
                <Plus className="w-4 h-4 mr-2" />
                New Ticket
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create New Ticket</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Title *</Label>
                  <Input
                    id="title"
                    placeholder="Brief description of the issue"
                    value={newTicket.title}
                    onChange={(e) => setNewTicket({ ...newTicket, title: e.target.value })}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Category</Label>
                    <Select 
                      value={newTicket.category} 
                      onValueChange={(v) => setNewTicket({ ...newTicket, category: v as TicketCategory })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(CATEGORY_LABELS).map(([value, label]) => (
                          <SelectItem key={value} value={value}>{label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Priority</Label>
                    <Select 
                      value={newTicket.priority} 
                      onValueChange={(v) => setNewTicket({ ...newTicket, priority: v as TicketPriority })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>Link to Batch (Optional)</Label>
                  <Select 
                    value={newTicket.linkedBatchId} 
                    onValueChange={(v) => setNewTicket({ ...newTicket, linkedBatchId: v })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a batch..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">None</SelectItem>
                      {batches.map(batch => (
                        <SelectItem key={batch.id} value={batch.id}>
                          {batch.batchNumber}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Description *</Label>
                  <Textarea
                    id="description"
                    placeholder="Detailed description of the problem..."
                    rows={4}
                    value={newTicket.description}
                    onChange={(e) => setNewTicket({ ...newTicket, description: e.target.value })}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleCreateTicket}
                  disabled={!newTicket.title.trim() || !newTicket.description.trim()}
                  className="bg-green-600 hover:bg-green-700"
                >
                  Create Ticket
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Open</p>
                <p className="text-2xl font-bold text-red-600">{ticketsByStatus.open.length}</p>
              </div>
              <AlertCircle className="w-8 h-8 text-red-200" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">In Progress</p>
                <p className="text-2xl font-bold text-yellow-600">{ticketsByStatus.in_progress.length}</p>
              </div>
              <Clock className="w-8 h-8 text-yellow-200" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Resolved</p>
                <p className="text-2xl font-bold text-green-600">{ticketsByStatus.resolved.length}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-200" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total</p>
                <p className="text-2xl font-bold text-gray-900">{tickets.length}</p>
              </div>
              <MoreHorizontal className="w-8 h-8 text-gray-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="Search tickets..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={selectedCategory} onValueChange={(v) => setSelectedCategory(v as TicketCategory | 'all')}>
          <SelectTrigger className="w-full sm:w-48">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Filter by category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {Object.entries(CATEGORY_LABELS).map(([value, label]) => (
              <SelectItem key={value} value={value}>{label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Tickets Board */}
      <Tabs defaultValue="open" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="open">
            Open ({ticketsByStatus.open.length})
          </TabsTrigger>
          <TabsTrigger value="in_progress">
            In Progress ({ticketsByStatus.in_progress.length})
          </TabsTrigger>
          <TabsTrigger value="resolved">
            Resolved ({ticketsByStatus.resolved.length})
          </TabsTrigger>
          <TabsTrigger value="closed">
            Closed ({ticketsByStatus.closed.length})
          </TabsTrigger>
        </TabsList>

        {(['open', 'in_progress', 'resolved', 'closed'] as TicketStatus[]).map((status) => (
          <TabsContent key={status} value={status}>
            {loading ? (
              <div className="text-center py-12">
                <div className="animate-spin w-8 h-8 border-2 border-green-600 border-t-transparent rounded-full mx-auto" />
                <p className="text-gray-500 mt-2">Loading tickets...</p>
              </div>
            ) : ticketsByStatus[status].length === 0 ? (
              <div className="text-center py-12 bg-gray-50 rounded-lg">
                <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">No {status.replace('_', ' ')} tickets</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {ticketsByStatus[status].map(renderTicketCard)}
              </div>
            )}
          </TabsContent>
        ))}
      </Tabs>

      {/* View Ticket Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          {selectedTicket && (
            <>
              <DialogHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-gray-500 mb-1">{selectedTicket.ticketNumber}</p>
                    <DialogTitle className="text-xl">{selectedTicket.title}</DialogTitle>
                  </div>
                  <Badge variant="outline" className={cn(PRIORITY_COLORS[selectedTicket.priority])}>
                    {selectedTicket.priority} priority
                  </Badge>
                </div>
              </DialogHeader>

              <div className="space-y-6">
                {/* Ticket Info */}
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline" className={cn(STATUS_COLORS[selectedTicket.status])}>
                    {selectedTicket.status.replace('_', ' ')}
                  </Badge>
                  <Badge variant="outline">
                    {CATEGORY_LABELS[selectedTicket.category]}
                  </Badge>
                  {selectedTicket.linkedBatch && (
                    <Badge variant="outline" className="bg-blue-50 text-blue-800">
                      <LinkIcon className="w-3 h-3 mr-1" />
                      {selectedTicket.linkedBatch.batchNumber}
                    </Badge>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500">Created by:</span>
                    <p className="font-medium flex items-center gap-1 mt-1">
                      <User className="w-4 h-4" />
                      {selectedTicket.createdByUser?.name || 'Unknown'}
                    </p>
                  </div>
                  <div>
                    <span className="text-gray-500">Created at:</span>
                    <p className="font-medium">
                      {format(new Date(selectedTicket.createdAt), 'MMM d, yyyy h:mm a')}
                    </p>
                  </div>
                  {selectedTicket.assignedToUser && (
                    <div>
                      <span className="text-gray-500">Assigned to:</span>
                      <p className="font-medium">{selectedTicket.assignedToUser.name}</p>
                    </div>
                  )}
                </div>

                <Separator />

                {/* Description */}
                <div>
                  <h4 className="font-medium mb-2">Description</h4>
                  <p className="text-gray-700 bg-gray-50 p-3 rounded-lg">
                    {selectedTicket.description}
                  </p>
                </div>

                {/* Resolution */}
                {(selectedTicket.status === 'resolved' || selectedTicket.status === 'closed') && selectedTicket.resolution && (
                  <div>
                    <h4 className="font-medium mb-2 flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      Resolution
                    </h4>
                    <p className="text-gray-700 bg-green-50 p-3 rounded-lg">
                      {selectedTicket.resolution}
                    </p>
                    {selectedTicket.resolvedAt && (
                      <p className="text-xs text-gray-500 mt-1">
                        Resolved on {format(new Date(selectedTicket.resolvedAt), 'MMM d, yyyy')}
                      </p>
                    )}
                  </div>
                )}

                <Separator />

                {/* Comments */}
                <div>
                  <h4 className="font-medium mb-3 flex items-center gap-2">
                    <MessageSquare className="w-4 h-4" />
                    Comments ({selectedTicket.comments.length})
                  </h4>
                  
                  <ScrollArea className="max-h-48">
                    <div className="space-y-3">
                      {selectedTicket.comments.length === 0 ? (
                        <p className="text-gray-500 text-sm">No comments yet</p>
                      ) : (
                        selectedTicket.comments.map((comment) => (
                          <div key={comment.id} className="bg-gray-50 p-3 rounded-lg">
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-medium text-sm">{comment.user?.name || 'Unknown'}</span>
                              <span className="text-xs text-gray-400">
                                {format(new Date(comment.createdAt), 'MMM d, h:mm a')}
                              </span>
                            </div>
                            <p className="text-sm text-gray-700">{comment.content}</p>
                          </div>
                        ))
                      )}
                    </div>
                  </ScrollArea>

                  {/* Add Comment */}
                  {selectedTicket.status !== 'closed' && (
                    <div className="mt-3 flex gap-2">
                      <Input
                        placeholder="Add a comment..."
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleAddComment()}
                      />
                      <Button onClick={handleAddComment} disabled={!newComment.trim()}>
                        Post
                      </Button>
                    </div>
                  )}
                </div>

                {/* Actions */}
                {canManageTickets && selectedTicket.status !== 'closed' && (
                  <>
                    <Separator />
                    <div className="space-y-3">
                      <h4 className="font-medium">Update Status</h4>
                      
                      {(selectedTicket.status === 'open' || selectedTicket.status === 'in_progress') && (
                        <div className="space-y-2">
                          <Label>Resolution Notes (required when resolving)</Label>
                          <Textarea
                            placeholder="Describe how the issue was resolved..."
                            value={resolution}
                            onChange={(e) => setResolution(e.target.value)}
                            rows={2}
                          />
                        </div>
                      )}
                      
                      <div className="flex flex-wrap gap-2">
                        {selectedTicket.status === 'open' && (
                          <Button 
                            onClick={() => handleUpdateStatus('in_progress')}
                            variant="outline"
                            className="border-yellow-500 text-yellow-700 hover:bg-yellow-50"
                          >
                            <Clock className="w-4 h-4 mr-2" />
                            Mark In Progress
                          </Button>
                        )}
                        {(selectedTicket.status === 'open' || selectedTicket.status === 'in_progress') && (
                          <Button 
                            onClick={() => handleUpdateStatus('resolved')}
                            disabled={!resolution.trim()}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Mark Resolved
                          </Button>
                        )}
                        {selectedTicket.status === 'resolved' && (
                          <Button 
                            onClick={() => handleUpdateStatus('closed')}
                            variant="outline"
                            className="border-gray-500"
                          >
                            <XCircle className="w-4 h-4 mr-2" />
                            Close Ticket
                          </Button>
                        )}
                      </div>
                    </div>
                  </>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
